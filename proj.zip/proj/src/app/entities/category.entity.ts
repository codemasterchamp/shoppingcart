export class Categroy {
    
        id: string;
        name: string;
    
    }
    
import { Injectable } from '@angular/core';

import { Product } from '../entities/product.entity';
import { Categroy } from 'src/app/entities/category.entity';

@Injectable()
export class ProductService {

    private products: Product[];
    private catogories: Categroy[];

    constructor() {
        this.catogories = [
            { id: 'cat1', name: 'Accessories'},
            { id: 'cat2', name: 'Mobile'},
            { id: 'cat3', name: 'Laptop'}
        ];

        this.products = [
            { id: 'p01', name: 'HeadPhone', price: 100, photo: 'img1.jpeg', category : 'cat1' },
            { id: 'p02', name: 'Mobile', price: 200, photo: 'img2.jpg', category : 'cat2' },
            { id: 'p03', name: 'Laptop', price: 300, photo: 'img3.jpg', category : 'cat3' },
            { id: 'p04', name: 'HeadPhone', price: 100, photo: 'img1.jpeg', category : 'cat1' },
        ];
    }

    findAll(): Product[] {
        return this.products;
    }

    categoryAll(): Categroy[] {
        return this.catogories;
    }

    find(id: string): Product {
        return this.products[this.getSelectedIndex(id)];
    }

    addProduct(data:Product): Product[] {      
        this.products.push(data);
        return this.products;

    }

    private getSelectedIndex(id: string) {
        for (var i = 0; i < this.products.length; i++) {
            if (this.products[i].id == id) {
                return i;
            }
        }
        return -1;
    }

}
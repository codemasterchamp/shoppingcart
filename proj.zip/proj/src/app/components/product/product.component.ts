import { Component, OnInit, Inject, Input } from '@angular/core';

import { Product } from '../../entities/product.entity';
import { Categroy } from '../../entities/category.entity';
import { ProductService } from '../../services/product.service';
import { FormGroup, FormBuilder } from "@angular/forms";

@Component({
	templateUrl: 'product.component.html'
})

export class ProductComponent implements OnInit {

  private products: Product[];
  private categories: Categroy[];
  private addfrm : boolean = false;
  private form: FormGroup;
  private photos: Categroy[];

  

	constructor(
		private productService: ProductService,@Input()private formBuilder: FormBuilder
  ) {
    
   }
  

	ngOnInit() {

    this.photos = [
      { id: 'cat0', name: 'img1.jpeg'},
      { id: 'cat1', name: 'img2.jpg'},
      { id: 'cat2', name: 'img3.jpg'}
  ];

    this.form = this.formBuilder.group({
      name: [''],
      photo: [''],
      price: [''],
      category:['']
    })
    this.products = this.productService.findAll();
    this.categories = this.productService.categoryAll();
  }

  filterForeCasts(filterVal: any) {
    if (filterVal == "0")
        this.products = this.productService.findAll();
    else {
        this.products = this.productService.findAll();
        this.products = this.products.filter((item) => item.category == filterVal);
    }
  }

  addproduct() {
    this.addfrm = true;
  }

  addproductclose() {
    this.addfrm = false;
  }

  submitForm() {
    this.addfrm = false;
    var pid = "p0"+ this.products.length +1;
    var catp = this.form.get('category').value.replace('cat','');
    var input = { id: pid, name: this.form.get('name').value, 
    price: this.form.get('price').value, 
    photo: this.photos[catp].name, 
    category : this.form.get('category').value };
    this.products = this.productService.addProduct(input);
  }

}